CMAKE_CUDA_RESOLVE_DEVICE_SYMBOLS
---------------------------------

.. versionadded:: 3.16

Default value for :prop_tgt:`CUDA_RESOLVE_DEVICE_SYMBOLS` target
property when defined. By default this variable is not defined.

This variable is used to initialize the property on each target as
it is created.

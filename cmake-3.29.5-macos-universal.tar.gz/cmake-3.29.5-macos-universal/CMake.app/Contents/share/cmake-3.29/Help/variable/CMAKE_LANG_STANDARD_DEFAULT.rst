CMAKE_<LANG>_STANDARD_DEFAULT
-----------------------------

.. versionadded:: 3.9

The compiler's default standard for the language ``<LANG>``. Empty if the
compiler has no conception of standard levels.

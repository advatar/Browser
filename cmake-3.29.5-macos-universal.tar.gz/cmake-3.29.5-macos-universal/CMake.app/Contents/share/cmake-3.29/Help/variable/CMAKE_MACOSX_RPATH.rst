CMAKE_MACOSX_RPATH
-------------------

Whether to use rpaths on macOS and iOS.

This variable is used to initialize the :prop_tgt:`MACOSX_RPATH` property on
all targets.

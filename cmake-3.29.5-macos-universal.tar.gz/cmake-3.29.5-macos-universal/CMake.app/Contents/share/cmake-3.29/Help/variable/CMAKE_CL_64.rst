CMAKE_CL_64
-----------

Discouraged.  Use :variable:`CMAKE_SIZEOF_VOID_P` instead.

Set to a true value when using a Microsoft Visual Studio ``cl`` compiler that
*targets* a 64-bit architecture.

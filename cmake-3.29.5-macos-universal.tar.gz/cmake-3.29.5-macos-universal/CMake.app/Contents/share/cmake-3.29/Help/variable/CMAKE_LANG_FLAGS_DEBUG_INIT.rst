CMAKE_<LANG>_FLAGS_DEBUG_INIT
-----------------------------

.. versionadded:: 3.7

This variable is the ``Debug`` variant of the
:variable:`CMAKE_<LANG>_FLAGS_<CONFIG>_INIT` variable.

CMAKE_<LANG>_COMPILER_LINKER_VERSION
------------------------------------

.. versionadded:: 3.29

Linker version string.

Linker version in major[.minor[.patch[.tweak]]] format.  This
variable is not guaranteed to be defined for all linkers or
languages.

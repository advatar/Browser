CMAKE_CUDA_HOST_COMPILER
------------------------

.. versionadded:: 3.10

This is the original CUDA-specific name for the more general
:variable:`CMAKE_<LANG>_HOST_COMPILER` variable.  See the latter
for details.
